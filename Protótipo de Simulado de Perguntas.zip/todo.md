## Fase 1: Planejamento e estruturação do simulado
- [x] Definir o formato das perguntas (múltipla escolha: 4 opções por pergunta).
- [x] Definir o número de perguntas por simulado (5 perguntas por simulado).
- [x] Definir o sistema de pontuação (1 ponto por acerto, sem penalidade por erro).
- [x] Definir o tipo de feedback (feedback ao final do simulado, mostrando pontuação e respostas corretas).
- [x] Escolher o tema das perguntas (Conhecimentos Gerais).

## Fase 2: Criação da base de perguntas e respostas
- [x] Criar um arquivo (e.g., JSON) com as perguntas, opções e respostas corretas

## Fase 3: Desenvolvimento da interface web
- [x] Configurar o ambiente de desenvolvimento (HTML, CSS, JavaScript)
- [x] Criar a estrutura básica da página (cabeçalho, área de perguntas, botões)
- [x] Estilizar a interface para ser amigável e responsiva

## Fase 4: Implementação da lógica do simulado
- [x] Carregar as perguntas do arquivo
- [x] Exibir uma pergunta por vez
- [x] Capturar a resposta do usuário
- [x] Verificar a resposta e calcular a pontuação
- [x] Exibir feedback ao usuário
- [x] Gerenciar a navegação entre as perguntas
- [x] Exibir o resultado final do simulado

## Fase 5: Teste e refinamento do protótipo
- [x] Testar a funcionalidade do simulado
- [x] Corrigir bugs e ajustar a interface
- [x] Garantir a responsividade em diferentes dispositivos

## Fase 6: Entrega do protótipo ao usuário
- [x] Empacotar os arquivos do protótipo
- [x] Fornecer instruções para execução
- [x] Apresentar o protótipo ao usuário

